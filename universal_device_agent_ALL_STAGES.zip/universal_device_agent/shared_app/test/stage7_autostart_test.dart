// Stage 7 (item 85, desktop): autostart helpers.
import 'dart:io';

import 'package:flutter_test/flutter_test.dart';
import 'package:shared_app/config/autostart.dart';

void main() {
  test('desktopExecQuote escapes quotes, backslashes, dollars and backticks', () {
    expect(AutostartService.desktopExecQuote('/opt/my app/agent'), '"/opt/my app/agent"');
    final q = AutostartService.desktopExecQuote(r'/o"pt/$x`y');
    expect(q.startsWith('"') && q.endsWith('"'), isTrue);
    expect(q.contains(r'\"'), isTrue);
    expect(q.contains(r'\$'), isTrue);
    expect(q.contains(r'\`'), isTrue);
  });

  test('linuxDesktopEntry is a valid autostart entry', () {
    final e = AutostartService.linuxDesktopEntry('/opt/agent');
    expect(e, startsWith('[Desktop Entry]\n'));
    expect(e, contains('Type=Application'));
    expect(e, contains('Exec="/opt/agent"'));
  });

  test('Linux enable/disable round-trips through the autostart file', () async {
    if (!Platform.isLinux) return;
    final home = Directory.systemTemp.createTempSync('uda_home_');
    addTearDown(() => home.deleteSync(recursive: true));
    final env = Platform.environment['XDG_CONFIG_HOME'];
    if (env != null && env.isNotEmpty) return; // XDG override => is test ko skip
    final s = AutostartService(executablePath: '/opt/agent', homeDir: home.path);
    expect(await s.isEnabled(), isFalse);
    expect(await s.enable(), isTrue);
    expect(await s.isEnabled(), isTrue);
    final f = File('${home.path}/.config/autostart/universal-device-agent.desktop');
    expect(f.readAsStringSync(), contains('Exec="/opt/agent"'));
    expect(await s.disable(), isTrue);
    expect(await s.isEnabled(), isFalse);
  });
}
