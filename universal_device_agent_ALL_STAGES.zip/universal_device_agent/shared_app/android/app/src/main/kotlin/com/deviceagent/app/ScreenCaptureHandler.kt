package com.deviceagent.app

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.util.Base64
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import io.flutter.embedding.engine.FlutterEngine
import io.flutter.plugin.common.EventChannel
import io.flutter.plugin.common.MethodChannel

/**
 * Native side of `ChannelNames.screenCapture` (MethodChannel) and
 * `ChannelNames.screenLiveStream` (EventChannel) from
 * platform_channel_bridge.dart — matches `ScreenCaptureBridge` in Dart.
 *
 * Flow:
 *  1. Dart calls "requestPermission" → MainActivity shows the mandatory
 *     Android system consent dialog (cannot be bypassed — Section 6.6
 *     item 2).
 *  2. On approval, MainActivity starts ScreenCaptureService with the
 *     granted resultCode/Intent.
 *  3. "captureScreenshot" → one-shot PNG, base64-encoded.
 *  4. EventChannel onListen → continuous JPEG frames for "Watch Live"
 *     (Section 2.1).
 */
class ScreenCaptureHandler(private val activity: MainActivity) {

    private var pendingPermissionResult: MethodChannel.Result? = null
    private val mainHandler = Handler(Looper.getMainLooper())

    fun register(flutterEngine: FlutterEngine) {
        val methodChannel = MethodChannel(
            flutterEngine.dartExecutor.binaryMessenger,
            ChannelNames.screenCapture
        )
        methodChannel.setMethodCallHandler { call, result ->
            when (call.method) {
                "requestPermission" -> requestPermission(result)
                "captureScreenshot" -> captureScreenshot(result)
                "stopStream" -> {
                    activity.currentScreenCaptureService()?.stopStreaming()
                    result.success(null)
                }
                else -> result.notImplemented()
            }
        }

        val eventChannel = EventChannel(
            flutterEngine.dartExecutor.binaryMessenger,
            ChannelNames.screenLiveStream
        )
        eventChannel.setStreamHandler(object : EventChannel.StreamHandler {
            override fun onListen(arguments: Any?, events: EventChannel.EventSink) {
                activity.currentScreenCaptureService()?.startStreaming { frameBytes ->
                    // Item 63: base64 encode background thread par; sirf
                    // result UI thread par post hota hai.
                    val encoded = Base64.encodeToString(frameBytes, Base64.NO_WRAP)
                    activity.runOnUiThread { events.success(encoded) }
                }
            }

            override fun onCancel(arguments: Any?) {
                activity.currentScreenCaptureService()?.stopStreaming()
            }
        })
    }

    /** Android 13+: foreground notification dikhane ke liye runtime permission. */
    private fun ensureNotificationPermission() {
        if (Build.VERSION.SDK_INT >= 33 &&
            ContextCompat.checkSelfPermission(
                activity, Manifest.permission.POST_NOTIFICATIONS
            ) != PackageManager.PERMISSION_GRANTED
        ) {
            ActivityCompat.requestPermissions(
                activity,
                arrayOf(Manifest.permission.POST_NOTIFICATIONS),
                MainActivity.REQUEST_CODE_NOTIFICATIONS_PERMISSION
            )
        }
    }

    private fun requestPermission(result: MethodChannel.Result) {
        // Item 74: pehle ki pending request overwrite ho kar hamesha ke
        // liye latak jati thi — ab usse false se complete karte hain.
        pendingPermissionResult?.success(false)
        pendingPermissionResult = result
        ensureNotificationPermission()
        val manager = activity.getSystemService(
            android.content.Context.MEDIA_PROJECTION_SERVICE
        ) as MediaProjectionManager
        activity.startActivityForResult(
            manager.createScreenCaptureIntent(),
            MainActivity.REQUEST_CODE_SCREEN_CAPTURE
        )
    }

    fun onPermissionResult(resultCode: Int, data: Intent?) {
        val pending = pendingPermissionResult
        pendingPermissionResult = null
        val granted = resultCode == Activity.RESULT_OK && data != null
        if (!granted) {
            pending?.success(false)
            return
        }

        // Item 74: Dart ko "granted" tab batate hain jab service ne
        // MediaProjection + VirtualDisplay sach mein bana liya — pehle
        // result turant chala jata tha aur agla captureScreenshot
        // `NOT_READY` se fail hota tha (race).
        var delivered = false
        fun deliver(ok: Boolean) {
            if (delivered) return
            delivered = true
            pending?.success(ok)
        }
        ScreenCaptureService.onSessionReady = { ok -> mainHandler.post { deliver(ok) } }
        mainHandler.postDelayed({
            if (!delivered) {
                ScreenCaptureService.onSessionReady = null
                deliver(false)
            }
        }, 8000)

        val serviceIntent = Intent(activity, ScreenCaptureService::class.java).apply {
            putExtra(ScreenCaptureService.EXTRA_RESULT_CODE, resultCode)
            putExtra(ScreenCaptureService.EXTRA_RESULT_DATA, data)
        }
        activity.startForegroundService(serviceIntent)
    }

    private fun captureScreenshot(result: MethodChannel.Result) {
        val service = activity.currentScreenCaptureService()
        if (service == null) {
            result.error("NOT_READY", "Screen capture session active nahi hai", null)
            return
        }
        // Item 63: PNG compress bhaari hai — main thread par ANR risk.
        Thread {
            val encoded = try {
                service.captureLatestFrameAsPng()?.let { Base64.encodeToString(it, Base64.NO_WRAP) }
            } catch (e: Exception) {
                null
            }
            activity.runOnUiThread {
                if (encoded == null) {
                    result.error("NOT_READY", "Abhi tak koi frame nahi mila — thodi der baad try karein", null)
                } else {
                    result.success(encoded)
                }
            }
        }.start()
    }
}
