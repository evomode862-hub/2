package com.deviceagent.app

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.IBinder
import android.os.PowerManager
import androidx.core.app.NotificationCompat

/**
 * Item 85: agent ko Android background mein zinda rakhne wali foreground
 * service. Yeh sirf **process ko high-priority par rakhti hai** (aur
 * partial wake lock se CPU network ke liye jaagta rehta hai) — asli agent
 * Dart isolate mein hi chalta hai. Isliye MainActivity back-press par task
 * ko background mein bhejti hai (finish nahi karti), taaki Flutter engine
 * (aur uska WebSocket) zinda rahe.
 *
 * Limits (honest): user app ko recents se swipe kare ya OS force-stop kare
 * to agent band ho jata hai; Android 15+ par bhi system aggressive OEM
 * battery managers (Xiaomi/Huawei...) ko user se "unrestricted battery"
 * dilwana padta hai (Permission Center mein item hai).
 */
class AgentForegroundService : Service() {

    companion object {
        private const val CHANNEL_ID = "agent_background_channel"
        private const val NOTIFICATION_ID = 1002
        @Volatile var running = false
            private set
    }

    private var wakeLock: PowerManager.WakeLock? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val notification = buildNotification()
        if (Build.VERSION.SDK_INT >= 34) {
            startForeground(NOTIFICATION_ID, notification, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        } else {
            startForeground(NOTIFICATION_ID, notification)
        }
        if (wakeLock == null) {
            val pm = getSystemService(POWER_SERVICE) as PowerManager
            wakeLock = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "DeviceAgent:agent").apply {
                setReferenceCounted(false)
                acquire() // service band hone par release (onDestroy)
            }
        }
        running = true
        return START_STICKY
    }

    private fun buildNotification(): Notification {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID, "Agent running", NotificationManager.IMPORTANCE_LOW
            )
            getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
        }
        val open = android.app.PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java),
            android.app.PendingIntent.FLAG_IMMUTABLE or android.app.PendingIntent.FLAG_UPDATE_CURRENT
        )
        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("Device Agent")
            .setContentText("Agent is connected and running in the background")
            .setSmallIcon(android.R.drawable.ic_menu_manage)
            .setOngoing(true)
            .setContentIntent(open)
            .build()
    }

    override fun onDestroy() {
        running = false
        try { wakeLock?.let { if (it.isHeld) it.release() } } catch (_: Exception) {}
        wakeLock = null
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null
}
