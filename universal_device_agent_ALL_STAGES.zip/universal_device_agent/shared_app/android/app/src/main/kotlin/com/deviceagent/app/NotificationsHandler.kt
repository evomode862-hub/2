package com.deviceagent.app

import android.content.ComponentName
import android.content.Intent
import android.provider.Settings
import androidx.core.app.NotificationManagerCompat
import io.flutter.embedding.engine.FlutterEngine
import io.flutter.plugin.common.MethodChannel

/** Item 84: Dart <-> [DeviceNotificationListener] bridge. */
class NotificationsHandler(private val activity: MainActivity) {

    fun register(flutterEngine: FlutterEngine) {
        MethodChannel(flutterEngine.dartExecutor.binaryMessenger, ChannelNames.notifications)
            .setMethodCallHandler { call, result ->
                when (call.method) {
                    "isEnabled" -> result.success(isEnabled())
                    "openSettings" -> {
                        activity.startActivity(
                            Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS)
                                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                        )
                        result.success(null)
                    }
                    "getRecent" -> {
                        if (!isEnabled()) {
                            result.error(
                                "PERMISSION_DENIED",
                                "Notification access enable nahi hai (Settings > Notification access)",
                                null
                            )
                            return@setMethodCallHandler
                        }
                        val limit = call.argument<Int>("limit") ?: 20
                        val since = (call.argument<Number>("since_ms") ?: 0L).toLong()
                        result.success(DeviceNotificationListener.recent(limit, since))
                    }
                    else -> result.notImplemented()
                }
            }
    }

    private fun isEnabled(): Boolean =
        NotificationManagerCompat.getEnabledListenerPackages(activity).contains(activity.packageName)
}
