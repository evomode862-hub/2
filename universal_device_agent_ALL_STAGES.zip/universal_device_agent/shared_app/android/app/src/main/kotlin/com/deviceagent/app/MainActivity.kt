package com.deviceagent.app

import android.content.Intent
import io.flutter.embedding.android.FlutterActivity
import io.flutter.embedding.engine.FlutterEngine

/**
 * Flutter entry point. Section 6.7: "sab channels register karta hai".
 *
 * Har naya capability isi file mein ek line add karega, apne handler ko
 * configureFlutterEngine() ke andar register karke — is se
 * `platform_channel_bridge.dart` ke ChannelNames se match hota hai.
 *
 * Screen Capture ke liye ek extra zimmedari bhi hai: MediaProjection
 * consent sirf ek Activity hi maang sakti hai (Section 6.6 item 2 —
 * mandatory system dialog, bypass nahi ho sakta), isliye
 * onActivityResult() yahan handle hota hai aur result
 * ScreenCaptureHandler ko forward hota hai.
 */
class MainActivity : FlutterActivity() {

    /**
     * Item 85: agent mode ON ho (foreground service chal rahi ho) to
     * back-press app ko **finish nahi karta**, sirf background mein bhejta
     * hai — warna FlutterActivity finish hone par Flutter engine (aur
     * usme chalta agent WebSocket) destroy ho jata hai.
     */
    @Volatile var agentModeEnabled: Boolean = false

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        if (agentModeEnabled) {
            moveTaskToBack(true)
        } else {
            @Suppress("DEPRECATION")
            super.onBackPressed()
        }
    }


    companion object {
        const val REQUEST_CODE_SCREEN_CAPTURE = 4242
        const val REQUEST_CODE_PICK_DIRECTORY = 4243
        const val REQUEST_CODE_LOCATION_PERMISSION = 4244
        const val REQUEST_CODE_CONTACTS_PERMISSION = 4245
        const val REQUEST_CODE_NOTIFICATIONS_PERMISSION = 4246
    }

    private lateinit var screenCaptureHandler: ScreenCaptureHandler
    private lateinit var filesHandler: FilesHandler
    private lateinit var locationNetworkHandler: LocationNetworkHandler
    private lateinit var contactsHandler: ContactsHandler

    override fun configureFlutterEngine(flutterEngine: FlutterEngine) {
        super.configureFlutterEngine(flutterEngine)
        PairingManager.register(flutterEngine, this)

        screenCaptureHandler = ScreenCaptureHandler(this)
        screenCaptureHandler.register(flutterEngine)

        InputHandler(this).register(flutterEngine)

        filesHandler = FilesHandler(this)
        filesHandler.register(flutterEngine)

        AppLauncherHandler(this).register(flutterEngine)

        ClipboardHandler(this).register(flutterEngine)

        BrowserHandler(this).register(flutterEngine)

        locationNetworkHandler = LocationNetworkHandler(this)
        locationNetworkHandler.register(flutterEngine)

        contactsHandler = ContactsHandler(this)
        contactsHandler.register(flutterEngine)

        // Audit fix (P1-05) — real lock/sleep/screen-off state.
        LockStateHandler(this).register(flutterEngine)

        NotificationsHandler(this).register(flutterEngine)
        BackgroundHandler(this).register(flutterEngine)

        // Aage: naye capabilities isi jagah register honge.
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        when (requestCode) {
            REQUEST_CODE_SCREEN_CAPTURE -> screenCaptureHandler.onPermissionResult(resultCode, data)
            REQUEST_CODE_PICK_DIRECTORY -> filesHandler.onDirectoryPicked(resultCode, data)
        }
    }

    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<out String>,
        grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        when (requestCode) {
            REQUEST_CODE_LOCATION_PERMISSION -> locationNetworkHandler.onPermissionResult(grantResults)
            REQUEST_CODE_CONTACTS_PERMISSION -> contactsHandler.onPermissionResult(grantResults)
        }
    }

    /** ScreenCaptureHandler ka helper — running service instance tak access. */
    fun currentScreenCaptureService(): ScreenCaptureService? = ScreenCaptureService.instance
}
