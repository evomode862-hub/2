// files_manager.cc
#include "files_manager.h"

#include <glib.h>

#include <filesystem>
#include <fstream>
#include <string>
#include <vector>

namespace fs = std::filesystem;

namespace {
constexpr char kChannel[] = "device_agent/files";

// Default sandbox root — $XDG_DATA_HOME/device-agent/sandbox (glib
// resolves this correctly per-distro). Doc ke "allowed-root filesystem
// sandbox" ka Linux-equivalent, koi extra permission ki zaroorat nahi.
fs::path SandboxRoot() {
  fs::path root = fs::path(g_get_user_data_dir()) / "device-agent" / "sandbox";
  std::error_code ec;
  fs::create_directories(root, ec);
  return root;
}

// Path traversal protection. User `pickDirectory()` se jo folder choose
// kare, uska path yahan "granted roots" mein add ho jaata hai — taaki
// poore device storage ko bhi (Windows wali file jaisi hi logic) isi
// Files capability se browse kiya ja sake.
// Item 81: IO cap (10 MiB — server ki upload limit ke barabar).
constexpr uintmax_t kMaxFileBytes = 10 * 1024 * 1024;

fs::path GrantedRootsFile() {
  return SandboxRoot().parent_path() / "granted_roots.txt";
}

// Item 82: granted roots ab restart ke baad bhi yaad rehte hain
// (ek path per line, text file).
std::vector<fs::path> LoadGrantedRoots() {
  std::vector<fs::path> roots;
  std::ifstream in(GrantedRootsFile());
  std::string line;
  while (std::getline(in, line)) {
    if (line.empty()) continue;
    std::error_code ec;
    fs::path p(line);
    if (fs::is_directory(p, ec)) roots.push_back(p);
  }
  return roots;
}

void SaveGrantedRoots(const std::vector<fs::path>& roots) {
  std::ofstream out(GrantedRootsFile(), std::ios::trunc);
  for (const auto& r : roots) out << r.string() << "\n";
}

std::vector<fs::path>& GrantedRoots() {
  static std::vector<fs::path> roots = LoadGrantedRoots();
  return roots;
}

// **Real bug jo yahan tha (Windows `files_manager.cpp` aur Android
// `FilesHandler.kt` dono mein wahi bug tha, teeno jagah fix kiya)**:
// bare string-prefix comparison tha, boundary check ke bina — matlab
// sandbox root `.../sandbox` ka koi sibling folder jaise
// `.../sandbox_other` bhi galti se "andar" maan liya jaata. Boundary
// check add kiya: target ya to root ke barabar ho, ya root + '/' se
// shuru ho.
bool IsPathUnder(const std::string& target_str, const std::string& root_str) {
  if (target_str == root_str) return true;
  if (target_str.size() <= root_str.size()) return false;
  if (target_str.compare(0, root_str.size(), root_str) != 0) return false;
  return target_str[root_str.size()] == '/';
}

fs::path ResolveSandboxed(const std::string& relative_path) {
  std::error_code ec;
  fs::path root = fs::weakly_canonical(SandboxRoot(), ec);

  fs::path requested(relative_path);
  if (requested.is_absolute()) {
    fs::path target = fs::weakly_canonical(requested, ec);
    if (ec || target.empty()) return {};  // item 81: invalid path => reject
    auto target_str = target.string();

    auto is_under = [&](const fs::path& allowed_root) {
      auto root_str = fs::weakly_canonical(allowed_root, ec).string();
      return IsPathUnder(target_str, root_str);
    };

    if (is_under(root)) return target;
    for (auto& granted : GrantedRoots()) {
      if (is_under(granted)) return target;
    }
    return {};
  }

  fs::path target = fs::weakly_canonical(root / relative_path, ec);
  if (!IsPathUnder(target.string(), root.string())) {
    return {};
  }
  return target;
}

// Item 81: Android jaisa consistent `path` — sandbox ke andar ho to root ke
// relative, warna (granted root) absolute. (Pehle hamesha absolute tha.)
std::string DisplayPath(const fs::path& p) {
  std::error_code ec;
  fs::path root = fs::weakly_canonical(SandboxRoot(), ec);
  fs::path c = fs::weakly_canonical(p, ec);
  if (!ec && !root.empty() && IsPathUnder(c.string(), root.string())) {
    fs::path rel = fs::relative(c, root, ec);
    if (!ec) return rel.string();
  }
  return p.string();
}

std::string Base64Encode(const std::vector<unsigned char>& bytes) {
  gchar* encoded = g_base64_encode(bytes.data(), bytes.size());
  std::string result(encoded);
  g_free(encoded);
  return result;
}

// Item 81: g_base64_decode invalid input par NULL/garbage de sakta hai.
// Ab strict validation + `false` return.
bool Base64Decode(const std::string& b64, std::vector<unsigned char>* out) {
  if (b64.empty()) {
    out->clear();
    return true;
  }
  gsize out_len = 0;
  guchar* decoded = g_base64_decode(b64.c_str(), &out_len);
  if (decoded == nullptr) return false;
  // Valid base64 ka decoded size ~3/4 hota hai; bahut chhota => invalid.
  if (out_len == 0 && b64.size() > 4) {
    g_free(decoded);
    return false;
  }
  out->assign(decoded, decoded + out_len);
  g_free(decoded);
  return true;
}

// GtkFileChooserDialog, modal + blocking (gtk_dialog_run) — MethodChannel
// handler ko synchronous response dena hai, isliye yeh sabse simple
// reliable tareeka hai (GTK ka apna recommended async pattern iske
// bajaye signal-based hota, lekin yahan blocking acceptable hai kyunki
// user-interaction ke dauran UI thread waise bhi wait karta).
std::string PickDirectoryBlocking(GtkWindow* parent) {
  GtkWidget* dialog = gtk_file_chooser_dialog_new(
      "Folder Chunein", parent, GTK_FILE_CHOOSER_ACTION_SELECT_FOLDER,
      "_Cancel", GTK_RESPONSE_CANCEL, "_Select", GTK_RESPONSE_ACCEPT, nullptr);

  std::string result;
  if (gtk_dialog_run(GTK_DIALOG(dialog)) == GTK_RESPONSE_ACCEPT) {
    g_autofree gchar* path =
        gtk_file_chooser_get_filename(GTK_FILE_CHOOSER(dialog));
    if (path != nullptr) result = path;
  }
  gtk_widget_destroy(dialog);
  return result;
}

static void method_call_cb(FlMethodChannel* channel, FlMethodCall* method_call,
                            gpointer user_data) {
  GtkWindow* window = static_cast<GtkWindow*>(user_data);
  const gchar* method = fl_method_call_get_name(method_call);
  FlValue* args = fl_method_call_get_args(method_call);
  g_autoptr(FlMethodResponse) response = nullptr;

  auto get_string = [&](const char* key) -> std::string {
    if (args == nullptr || fl_value_get_type(args) != FL_VALUE_TYPE_MAP) return "";
    FlValue* v = fl_value_lookup_string(args, key);
    if (v == nullptr || fl_value_get_type(v) != FL_VALUE_TYPE_STRING) return "";
    return fl_value_get_string(v);
  };

  if (g_strcmp0(method, "getAllowedRoot") == 0) {
    auto& roots = GrantedRoots();
    g_autoptr(FlValue) result = fl_value_new_string(
        roots.empty() ? SandboxRoot().c_str() : roots.back().c_str());
    response = FL_METHOD_RESPONSE(fl_method_success_response_new(result));

  } else if (g_strcmp0(method, "listDirectory") == 0) {
    fs::path dir = ResolveSandboxed(get_string("path"));
    std::error_code ec;
    if (dir.empty() || !fs::is_directory(dir, ec)) {
      response = FL_METHOD_RESPONSE(fl_method_error_response_new(
          "NOT_FOUND", "Directory nahi mili ya sandbox se bahar hai", nullptr));
    } else {
      g_autoptr(FlValue) list = fl_value_new_list();
      // Item 81: non-throwing overloads (`ec`) — ek unreadable entry poori
      // process ko crash nahi karti.
      fs::directory_iterator it(dir, fs::directory_options::skip_permission_denied, ec);
      for (fs::directory_iterator end; !ec && it != end; it.increment(ec)) {
        std::error_code e2;
        const auto& entry = *it;
        bool is_dir = entry.is_directory(e2);
        bool is_file = !e2 && entry.is_regular_file(e2);
        uintmax_t size = 0;
        if (is_file) {
          size = entry.file_size(e2);
          if (e2) size = 0;
        }
        g_autoptr(FlValue) m = fl_value_new_map();
        fl_value_set_string_take(m, "name",
            fl_value_new_string(entry.path().filename().c_str()));
        fl_value_set_string_take(m, "isDirectory", fl_value_new_bool(is_dir));
        fl_value_set_string_take(m, "size",
            fl_value_new_int(static_cast<int64_t>(size)));
        fl_value_set_string_take(m, "path",
            fl_value_new_string(DisplayPath(entry.path()).c_str()));
        fl_value_append(list, m);
      }
      response = FL_METHOD_RESPONSE(fl_method_success_response_new(list));
    }

  } else if (g_strcmp0(method, "readFile") == 0) {
    fs::path file = ResolveSandboxed(get_string("path"));
    std::error_code ec;
    if (file.empty() || !fs::is_regular_file(file, ec)) {
      response = FL_METHOD_RESPONSE(
          fl_method_error_response_new("NOT_FOUND", "File nahi mili", nullptr));
    } else {
      uintmax_t fsize = fs::file_size(file, ec);
      if (ec) {
        response = FL_METHOD_RESPONSE(fl_method_error_response_new(
            "READ_FAILED", "File size nahi mil saka", nullptr));
      } else if (fsize > kMaxFileBytes) {
        response = FL_METHOD_RESPONSE(fl_method_error_response_new(
            "TOO_LARGE", "File 10 MiB se badi hai", nullptr));
      } else {
        std::ifstream in(file, std::ios::binary);
        if (!in) {
          response = FL_METHOD_RESPONSE(fl_method_error_response_new(
              "READ_FAILED", "File open nahi hui", nullptr));
        } else {
          std::vector<unsigned char> bytes((std::istreambuf_iterator<char>(in)),
                                            std::istreambuf_iterator<char>());
          g_autoptr(FlValue) result = fl_value_new_string(Base64Encode(bytes).c_str());
          response = FL_METHOD_RESPONSE(fl_method_success_response_new(result));
        }
      }
    }

  } else if (g_strcmp0(method, "writeFile") == 0) {
    fs::path file = ResolveSandboxed(get_string("path"));
    if (file.empty()) {
      response = FL_METHOD_RESPONSE(fl_method_error_response_new(
          "FORBIDDEN", "Sandbox se bahar likhna mana hai", nullptr));
    } else {
      std::error_code ec;
      fs::create_directories(file.parent_path(), ec);
      std::vector<unsigned char> bytes;
      if (!Base64Decode(get_string("data"), &bytes)) {
        response = FL_METHOD_RESPONSE(fl_method_error_response_new(
            "INVALID_DATA", "Data valid base64 nahi hai", nullptr));
      } else if (bytes.size() > kMaxFileBytes) {
        response = FL_METHOD_RESPONSE(fl_method_error_response_new(
            "TOO_LARGE", "Data 10 MiB se bada hai", nullptr));
      } else {
        std::ofstream out(file, std::ios::binary | std::ios::trunc);
        if (!out) {
          response = FL_METHOD_RESPONSE(fl_method_error_response_new(
              "WRITE_FAILED", "File open/create nahi ho saki", nullptr));
        } else {
          out.write(reinterpret_cast<const char*>(bytes.data()),
                    static_cast<std::streamsize>(bytes.size()));
          out.flush();
          if (!out) {
            response = FL_METHOD_RESPONSE(fl_method_error_response_new(
                "WRITE_FAILED", "Write complete nahi hua", nullptr));
          } else {
            g_autoptr(FlValue) result = fl_value_new_bool(true);
            response = FL_METHOD_RESPONSE(fl_method_success_response_new(result));
          }
        }
      }
    }

  } else if (g_strcmp0(method, "deleteFile") == 0) {
    fs::path file = ResolveSandboxed(get_string("path"));
    std::error_code ec;
    bool ok = !file.empty() && fs::remove(file, ec);
    g_autoptr(FlValue) result = fl_value_new_bool(ok);
    response = FL_METHOD_RESPONSE(fl_method_success_response_new(result));

  } else if (g_strcmp0(method, "pickDirectory") == 0) {
    std::string picked = PickDirectoryBlocking(window);
    if (!picked.empty()) {
      auto& roots = GrantedRoots();
      fs::path p(picked);
      bool already = false;
      for (const auto& r : roots) {
        if (r == p) { already = true; break; }
      }
      if (!already) {
        roots.push_back(p);
        SaveGrantedRoots(roots);  // item 82
      }
    }
    g_autoptr(FlValue) result =
        picked.empty() ? nullptr : fl_value_new_string(picked.c_str());
    response = FL_METHOD_RESPONSE(fl_method_success_response_new(result));

  } else {
    response = FL_METHOD_RESPONSE(fl_method_not_implemented_response_new());
  }

  g_autoptr(GError) error = nullptr;
  if (!fl_method_call_respond(method_call, response, &error)) {
    g_warning("Files channel response failed: %s", error->message);
  }
}
}  // namespace

void files_manager_register(FlEngine* engine, GtkWindow* window) {
  g_autoptr(FlStandardMethodCodec) codec = fl_standard_method_codec_new();
  FlBinaryMessenger* messenger = fl_engine_get_binary_messenger(engine);
  FlMethodChannel* channel =
      fl_method_channel_new(messenger, kChannel, FL_METHOD_CODEC(codec));
  fl_method_channel_set_method_call_handler(channel, method_call_cb, window,
                                             nullptr);
}
