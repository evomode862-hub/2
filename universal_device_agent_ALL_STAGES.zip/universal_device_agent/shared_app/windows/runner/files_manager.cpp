// files_manager.cpp
#include "files_manager.h"

#include <flutter/method_channel.h>
#include <flutter/standard_method_codec.h>

#include <shobjidl.h>
#include <wincrypt.h>
#include <wrl/client.h>

#include <filesystem>
#include <fstream>
#include <memory>
#include <string>
#include <vector>

namespace fs = std::filesystem;

namespace {
constexpr char kChannel[] = "device_agent/files";

// Default sandbox root — %LOCALAPPDATA%\DeviceAgent\sandbox. Doc ke
// "allowed-root filesystem sandbox" (Section 6.7 file-list comment) ka
// Windows-equivalent; koi extra Windows permission nahi chahiye is
// folder ke liye kyunki yeh already user-writable hai.
fs::path SandboxRoot() {
  wchar_t* local_app_data = nullptr;
  fs::path root;
  if (SUCCEEDED(SHGetKnownFolderPath(FOLDERID_LocalAppData, 0, nullptr,
                                      &local_app_data))) {
    root = fs::path(local_app_data) / L"DeviceAgent" / L"sandbox";
    CoTaskMemFree(local_app_data);
  } else {
    root = fs::temp_directory_path() / L"DeviceAgentSandbox";
  }
  std::error_code ec;
  fs::create_directories(root, ec);
  return root;
}

// Path traversal protection: relative_path ko sandbox root ke andar
// resolve karta hai, agar bahar nikal jaaye to empty path return karta
// hai (caller ise "forbidden" treat kare).
//
// User `pickDirectory()` se jo folder choose kare, uska absolute path
// yahan "granted roots" mein add ho jaata hai — taaki poore device
// storage ko bhi (jaise C:\ ya koi bhi user-chuni hui drive/folder)
// isi Files capability se browse kiya ja sake, sandbox root tak
// limited rahe bina. Yeh list sirf is process ke lifetime tak rehti
// hai (persist nahi hoti) — har naye session mein dobara pick karna
// padega, jo intentional hai (Section 3 ke scoped-permission spirit
// ke mutabiq, ek baar di gayi broad access hamesha ke liye silently
// yaad nahi rehni chahiye).
// Item 81: IO cap (10 MiB — server ki upload limit ke barabar).
constexpr uintmax_t kMaxFileBytes = 10 * 1024 * 1024;

fs::path GrantedRootsFile() {
  return SandboxRoot().parent_path() / L"granted_roots.txt";
}

// Item 82: pehle granted roots sirf memory mein the (upar wala comment
// purana tha) — ab ek UTF-8 text file (ek path per line) mein persist hote
// hain. Dhyan: user ne explicitly folder chuna tha, aur Permission Center
// se dobara chunke badla/hataya ja sakta hai.
std::vector<fs::path> LoadGrantedRoots() {
  std::vector<fs::path> roots;
  std::ifstream in(GrantedRootsFile(), std::ios::binary);
  std::string line;
  while (std::getline(in, line)) {
    if (!line.empty() && line.back() == '\r') line.pop_back();
    if (line.empty()) continue;
    std::error_code ec;
    fs::path p = fs::u8path(line);
    if (fs::is_directory(p, ec)) roots.push_back(p);  // ab nahi bachi to skip
  }
  return roots;
}

void SaveGrantedRoots(const std::vector<fs::path>& roots) {
  std::ofstream out(GrantedRootsFile(), std::ios::binary | std::ios::trunc);
  for (const auto& r : roots) {
    out << r.u8string() << "\n";
  }
}

std::vector<fs::path>& GrantedRoots() {
  static std::vector<fs::path> roots = LoadGrantedRoots();
  return roots;
}

// `weakly_canonical` throw kar sakta hai — native crash ki jagah empty path.
fs::path SafeCanonical(const fs::path& p) {
  std::error_code ec;
  fs::path c = fs::weakly_canonical(p, ec);
  return ec ? fs::path() : c;
}

// **Real bug jo yahan tha (Android `FilesHandler.kt` mein bhi wahi bug
// tha, dono jagah fix kiya)**: neeche do jagah bare string-prefix
// comparison tha (`compare(0, root_str.size(), root_str) == 0`), boundary
// check ke bina. Iska matlab: agar sandbox root ho
// `C:\...\DeviceAgent\sandbox`, to ek SIBLING folder jiska naam bhi isi
// prefix se shuru ho — jaise `C:\...\DeviceAgent\sandbox_other` — is
// check ko galti se pass kar jaata, kyunki string-wise woh prefix match
// kar raha hota hai, chahe woh asal mein us directory ke andar na ho.
// Yeh helper sahi boundary check karta hai: target ya to root ke
// EXACTLY barabar ho, ya root + path-separator se shuru ho.
bool IsPathUnder(const std::wstring& target_str, const std::wstring& root_str) {
  if (target_str == root_str) return true;
  if (target_str.size() <= root_str.size()) return false;
  if (target_str.compare(0, root_str.size(), root_str) != 0) return false;
  wchar_t next = target_str[root_str.size()];
  return next == L'\\' || next == L'/';
}

fs::path ResolveSandboxed(const std::string& relative_path) {
  fs::path root = SafeCanonical(SandboxRoot());
  if (root.empty()) return {};

  // UTF-8 se path (narrow `fs::path(std::string)` ANSI code page use
  // karta tha — non-ASCII filenames toot'te the).
  fs::path requested = fs::u8path(relative_path);
  if (requested.is_absolute()) {
    // Absolute path — sirf tab allowed jab woh sandbox root ke andar ho
    // YA user ne explicitly pickDirectory() se grant kiya ho.
    fs::path target = SafeCanonical(requested);
    if (target.empty()) return {};
    auto target_str = target.wstring();

    auto is_under = [&](const fs::path& allowed_root) {
      fs::path c = SafeCanonical(allowed_root);
      return !c.empty() && IsPathUnder(target_str, c.wstring());
    };

    if (is_under(root)) return target;
    for (auto& granted : GrantedRoots()) {
      if (is_under(granted)) return target;
    }
    return {};
  }

  // Relative path — hamesha sandbox root ke andar resolve hota hai.
  fs::path target = SafeCanonical(root / requested);
  if (target.empty() || !IsPathUnder(target.wstring(), root.wstring())) {
    return {};
  }
  return target;
}

// Item 81: Android jaisa consistent `path` — sandbox ke andar ho to root ke
// relative, warna (granted root) absolute.
std::string DisplayPath(const fs::path& p) {
  fs::path root = SafeCanonical(SandboxRoot());
  fs::path c = SafeCanonical(p);
  if (!root.empty() && !c.empty() && IsPathUnder(c.wstring(), root.wstring())) {
    std::error_code ec;
    fs::path rel = fs::relative(c, root, ec);
    if (!ec) return rel.u8string();
  }
  return p.u8string();
}

std::string Base64Encode(const std::vector<unsigned char>& bytes) {
  DWORD out_len = 0;
  CryptBinaryToStringA(bytes.data(), static_cast<DWORD>(bytes.size()),
                        CRYPT_STRING_BASE64 | CRYPT_STRING_NOCRLF, nullptr,
                        &out_len);
  std::string out(out_len, '\0');
  CryptBinaryToStringA(bytes.data(), static_cast<DWORD>(bytes.size()),
                        CRYPT_STRING_BASE64 | CRYPT_STRING_NOCRLF, out.data(),
                        &out_len);
  out.resize(out_len > 0 ? out_len - 1 : 0);  // trailing NUL trim
  return out;
}

// Item 81: invalid base64 par pehle chup-chaap ghalat data likh kar `true`
// milta tha. Ab `false` return hota hai.
bool Base64Decode(const std::string& b64, std::vector<unsigned char>* out) {
  DWORD out_len = 0;
  if (!CryptStringToBinaryA(b64.c_str(), static_cast<DWORD>(b64.size()),
                            CRYPT_STRING_BASE64, nullptr, &out_len, nullptr,
                            nullptr)) {
    return false;
  }
  out->assign(out_len, 0);
  if (!CryptStringToBinaryA(b64.c_str(), static_cast<DWORD>(b64.size()),
                            CRYPT_STRING_BASE64, out->data(), &out_len,
                            nullptr, nullptr)) {
    return false;
  }
  out->resize(out_len);
  return true;
}

// Native folder picker — IFileDialog with FOS_PICKFOLDERS, broader
// user-granted access ke liye (sandbox root se bahar).
std::string PickDirectory(HWND owner) {
  Microsoft::WRL::ComPtr<IFileDialog> dialog;
  if (FAILED(CoCreateInstance(CLSID_FileOpenDialog, nullptr, CLSCTX_INPROC_SERVER,
                               IID_PPV_ARGS(&dialog)))) {
    return "";
  }
  DWORD flags = 0;
  dialog->GetOptions(&flags);
  dialog->SetOptions(flags | FOS_PICKFOLDERS);

  if (FAILED(dialog->Show(owner))) return "";

  Microsoft::WRL::ComPtr<IShellItem> item;
  if (FAILED(dialog->GetResult(&item))) return "";

  PWSTR path_wide = nullptr;
  if (FAILED(item->GetDisplayName(SIGDN_FILESYSPATH, &path_wide))) return "";

  int size = WideCharToMultiByte(CP_UTF8, 0, path_wide, -1, nullptr, 0,
                                  nullptr, nullptr);
  std::string result(size, 0);
  WideCharToMultiByte(CP_UTF8, 0, path_wide, -1, result.data(), size,
                       nullptr, nullptr);
  CoTaskMemFree(path_wide);
  if (!result.empty() && result.back() == '\0') result.pop_back();
  return result;
}
}  // namespace

void FilesManager::Register(flutter::FlutterEngine* engine, HWND window_handle) {
  auto channel = std::make_shared<flutter::MethodChannel<flutter::EncodableValue>>(
      engine->messenger(), kChannel,
      &flutter::StandardMethodCodec::GetInstance());

  channel->SetMethodCallHandler(
      [channel, window_handle](
          const flutter::MethodCall<flutter::EncodableValue>& call,
          std::unique_ptr<flutter::MethodResult<flutter::EncodableValue>> result) {
        const auto* args = std::get_if<flutter::EncodableMap>(call.arguments());
        auto get_string = [&](const char* key) -> std::string {
          if (!args) return "";
          auto it = args->find(flutter::EncodableValue(key));
          if (it == args->end()) return "";
          if (auto v = std::get_if<std::string>(&it->second)) return *v;
          return "";
        };

        if (call.method_name() == "getAllowedRoot") {
          auto& roots = GrantedRoots();
          result->Success(flutter::EncodableValue(
              roots.empty() ? SandboxRoot().u8string() : roots.back().u8string()));

        } else if (call.method_name() == "listDirectory") {
          fs::path dir = ResolveSandboxed(get_string("path"));
          std::error_code ec;
          if (dir.empty() || !fs::is_directory(dir, ec)) {
            result->Error("NOT_FOUND", "Directory nahi mili ya sandbox se bahar hai");
            return;
          }
          flutter::EncodableList entries;
          // Item 81: non-throwing overloads (`ec` ke saath) — ek unreadable
          // entry poori native process ko crash nahi karti.
          fs::directory_iterator it(dir, fs::directory_options::skip_permission_denied, ec);
          for (fs::directory_iterator end; !ec && it != end; it.increment(ec)) {
            std::error_code e2;
            const auto& entry = *it;
            bool is_dir = entry.is_directory(e2);
            bool is_file = !e2 && entry.is_regular_file(e2);
            uintmax_t size = 0;
            if (is_file) {
              size = entry.file_size(e2);
              if (e2) size = 0;
            }
            flutter::EncodableMap m;
            m[flutter::EncodableValue("name")] =
                flutter::EncodableValue(entry.path().filename().u8string());
            m[flutter::EncodableValue("isDirectory")] = flutter::EncodableValue(is_dir);
            m[flutter::EncodableValue("size")] =
                flutter::EncodableValue(static_cast<int64_t>(size));
            m[flutter::EncodableValue("path")] =
                flutter::EncodableValue(DisplayPath(entry.path()));
            entries.push_back(flutter::EncodableValue(m));
          }
          result->Success(flutter::EncodableValue(entries));

        } else if (call.method_name() == "readFile") {
          fs::path file = ResolveSandboxed(get_string("path"));
          std::error_code ec;
          if (file.empty() || !fs::is_regular_file(file, ec)) {
            result->Error("NOT_FOUND", "File nahi mili");
            return;
          }
          uintmax_t fsize = fs::file_size(file, ec);
          if (ec) {
            result->Error("READ_FAILED", "File size nahi mil saka");
            return;
          }
          if (fsize > kMaxFileBytes) {
            result->Error("TOO_LARGE", "File 10 MiB se badi hai");
            return;
          }
          std::ifstream in(file, std::ios::binary);
          if (!in) {
            result->Error("READ_FAILED", "File open nahi hui");
            return;
          }
          std::vector<unsigned char> bytes(
              (std::istreambuf_iterator<char>(in)), std::istreambuf_iterator<char>());
          result->Success(flutter::EncodableValue(Base64Encode(bytes)));

        } else if (call.method_name() == "writeFile") {
          fs::path file = ResolveSandboxed(get_string("path"));
          if (file.empty()) {
            result->Error("FORBIDDEN", "Sandbox se bahar likhna mana hai");
            return;
          }
          std::error_code ec;
          fs::create_directories(file.parent_path(), ec);
          std::vector<unsigned char> bytes;
          if (!Base64Decode(get_string("data"), &bytes)) {
            result->Error("INVALID_DATA", "Data valid base64 nahi hai");
            return;
          }
          if (bytes.size() > kMaxFileBytes) {
            result->Error("TOO_LARGE", "Data 10 MiB se bada hai");
            return;
          }
          std::ofstream out(file, std::ios::binary | std::ios::trunc);
          if (!out) {
            result->Error("WRITE_FAILED", "File open/create nahi ho saki");
            return;
          }
          out.write(reinterpret_cast<const char*>(bytes.data()),
                    static_cast<std::streamsize>(bytes.size()));
          out.flush();
          if (!out) {
            result->Error("WRITE_FAILED", "Write complete nahi hua");
            return;
          }
          result->Success(flutter::EncodableValue(true));

        } else if (call.method_name() == "deleteFile") {
          fs::path file = ResolveSandboxed(get_string("path"));
          std::error_code ec;
          bool ok = !file.empty() && fs::remove(file, ec);
          result->Success(flutter::EncodableValue(ok));

        } else if (call.method_name() == "pickDirectory") {
          std::string picked = PickDirectory(window_handle);
          if (picked.empty()) {
            result->Success();
          } else {
            auto& roots = GrantedRoots();
            fs::path p = fs::u8path(picked);
            bool already = false;
            for (const auto& r : roots) {
              if (r == p) { already = true; break; }
            }
            if (!already) {
              roots.push_back(p);
              SaveGrantedRoots(roots);  // item 82: restart ke baad bhi yaad
            }
            result->Success(flutter::EncodableValue(picked));
          }

        } else {
          result->NotImplemented();
        }
      });
}
