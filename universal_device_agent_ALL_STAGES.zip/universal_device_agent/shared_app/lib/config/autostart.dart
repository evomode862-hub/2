/// Item 85 (desktop): login par agent apne aap start ho — Windows (HKCU Run
/// key) aur Linux (XDG autostart `.desktop` file). Android ke liye alag
/// foreground service hai (`BackgroundBridge`).
///
/// Sirf current user ke liye (admin/root nahi chahiye), aur user Permission
/// Center se kabhi bhi band kar sakta hai.
library;

import 'dart:io';

const _runKey = r'HKCU\Software\Microsoft\Windows\CurrentVersion\Run';
const _valueName = 'UniversalDeviceAgent';

class AutostartService {
  /// Test ke liye override ho sakta hai.
  final String executablePath;
  final String? homeDir;
  final Future<ProcessResult> Function(String exe, List<String> args) runProcess;

  AutostartService({
    String? executablePath,
    this.homeDir,
    Future<ProcessResult> Function(String, List<String>)? runProcess,
  })  : executablePath = executablePath ?? Platform.resolvedExecutable,
        runProcess = runProcess ?? Process.run;

  bool get isSupported => Platform.isWindows || Platform.isLinux;

  File get _linuxFile {
    final home = homeDir ?? Platform.environment['HOME'] ?? '';
    final xdg = Platform.environment['XDG_CONFIG_HOME'];
    final base = (xdg != null && xdg.isNotEmpty) ? xdg : '$home/.config';
    return File('$base/autostart/universal-device-agent.desktop');
  }

  /// Linux `.desktop` Exec line ke liye path quote/escape (spaces, quotes).
  static String desktopExecQuote(String path) {
    final escaped = path
        .replaceAll(r'\', r'\\\\')
        .replaceAll('"', r'\"')
        .replaceAll(r'$', r'\$')
        .replaceAll('`', r'\`');
    return '"$escaped"';
  }

  static String linuxDesktopEntry(String exePath) => '[Desktop Entry]\n'
      'Type=Application\n'
      'Name=Universal Device Agent\n'
      'Exec=${desktopExecQuote(exePath)}\n'
      'X-GNOME-Autostart-enabled=true\n'
      'NoDisplay=false\n';

  Future<bool> isEnabled() async {
    if (Platform.isLinux) return _linuxFile.exists();
    if (Platform.isWindows) {
      final r = await runProcess('reg', ['query', _runKey, '/v', _valueName]);
      return r.exitCode == 0;
    }
    return false;
  }

  Future<bool> enable() async {
    if (Platform.isLinux) {
      final f = _linuxFile;
      await f.parent.create(recursive: true);
      await f.writeAsString(linuxDesktopEntry(executablePath));
      return true;
    }
    if (Platform.isWindows) {
      // Args list ke roop mein (shell string nahi) — injection nahi.
      final r = await runProcess('reg', [
        'add', _runKey, '/v', _valueName, '/t', 'REG_SZ',
        '/d', '"$executablePath"', '/f',
      ]);
      return r.exitCode == 0;
    }
    return false;
  }

  Future<bool> disable() async {
    if (Platform.isLinux) {
      final f = _linuxFile;
      if (await f.exists()) await f.delete();
      return true;
    }
    if (Platform.isWindows) {
      final r = await runProcess('reg', ['delete', _runKey, '/v', _valueName, '/f']);
      return r.exitCode == 0;
    }
    return false;
  }
}
