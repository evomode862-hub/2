import 'package:flutter/material.dart';
import '../protocol/api_client.dart';
import 'activity_history_screen.dart';
import 'device_status_screen.dart';
import 'key_manager_screen.dart';
import '../task_monitor/active_tasks_screen.dart';
import '../task_monitor/background_tasks_screen.dart';
import 'permission_center.dart';

/// Section 10.1 ka "My Phone" card + navigation shortcuts — [ View Status ]
/// [ Background Tasks ] [ Activity History ] — plus Key Manager, jo poore
/// dashboard/ module ko ek jagah wire karta hai.
class HomeDashboard extends StatelessWidget {
  final DeviceAgentApiClient api;
  final String deviceId;

  /// Items 30: Tasks screen ko WebSocket base URL chahiye.
  final Uri wsBaseUrl;

  /// Item 21: unpair ka callback (credentials clear + wapas pairing).
  final Future<void> Function()? onUnpair;

  const HomeDashboard({
    super.key,
    required this.api,
    required this.deviceId,
    required this.wsBaseUrl,
    this.onUnpair,
  });

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Universal Device Agent')),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          _tile(
            context,
            icon: Icons.devices_other,
            title: 'Device Status',
            subtitle: 'Power / Lock / Screen / Location / Network',
            onTap: () => Navigator.push(
              context,
              MaterialPageRoute(
                builder: (_) =>
                    DeviceStatusScreen(api: api, deviceId: deviceId),
              ),
            ),
          ),
          _tile(
            context,
            icon: Icons.play_circle_outline,
            title: 'Tasks',
            subtitle: 'Active/recent tasks — monitor, pause, stop, watch live',
            onTap: () => Navigator.push(
              context,
              MaterialPageRoute(
                builder: (_) =>
                    ActiveTasksScreen(api: api, wsBaseUrl: wsBaseUrl),
              ),
            ),
          ),
          _tile(
            context,
            icon: Icons.verified_user_outlined,
            title: 'Permission Center',
            subtitle: 'Screen capture, accessibility, files, contacts, location',
            onTap: () => Navigator.push(
              context,
              MaterialPageRoute(builder: (_) => const PermissionCenterScreen()),
            ),
          ),
          _tile(
            context,
            icon: Icons.bolt,
            title: 'Background Tasks',
            subtitle: 'Locked-device agent, notifications, messaging',
            onTap: () => Navigator.push(
              context,
              MaterialPageRoute(
                builder: (_) =>
                    BackgroundTasksScreen(api: api, deviceId: deviceId),
              ),
            ),
          ),
          _tile(
            context,
            icon: Icons.history,
            title: 'Activity History',
            subtitle: 'Unified log of everything the agent has done',
            onTap: () => Navigator.push(
              context,
              MaterialPageRoute(
                builder: (_) =>
                    ActivityHistoryScreen(api: api, deviceId: deviceId),
              ),
            ),
          ),
          _tile(
            context,
            icon: Icons.vpn_key,
            title: 'API Keys',
            subtitle: 'Create/revoke scoped keys (Master Key Generator)',
            onTap: () => Navigator.push(
              context,
              MaterialPageRoute(builder: (_) => KeyManagerScreen(api: api)),
            ),
          ),
          if (onUnpair != null)
            _tile(
              context,
              icon: Icons.link_off,
              title: 'Unpair this device',
              subtitle: 'Server se hatao, saari API keys revoke, local data clear',
              onTap: () async {
                final sure = await showDialog<bool>(
                  context: context,
                  builder: (ctx) => AlertDialog(
                    title: const Text('Unpair device?'),
                    content: const Text(
                        'Is device ki saari API keys aur tasks server se hat jayenge.'),
                    actions: [
                      TextButton(
                          onPressed: () => Navigator.pop(ctx, false),
                          child: const Text('Cancel')),
                      FilledButton(
                          onPressed: () => Navigator.pop(ctx, true),
                          child: const Text('Unpair')),
                    ],
                  ),
                );
                if (sure == true) await onUnpair!();
              },
            ),
        ],
      ),
    );
  }

  Widget _tile(
    BuildContext context, {
    required IconData icon,
    required String title,
    required String subtitle,
    required VoidCallback onTap,
  }) {
    return Card(
      child: ListTile(
        leading: Icon(icon),
        title: Text(title),
        subtitle: Text(subtitle),
        trailing: const Icon(Icons.chevron_right),
        onTap: onTap,
      ),
    );
  }
}
