import 'package:flutter/material.dart';
import 'package:qr_flutter/qr_flutter.dart';
import 'dart:convert';
import '../protocol/api_client.dart';
import '../protocol/api_key.dart';
import '../protocol/capability_manifest.dart';
import 'permission_wizard.dart';

class KeyManagerScreen extends StatefulWidget {
  final DeviceAgentApiClient api;
  const KeyManagerScreen({super.key, required this.api});

  @override
  State<KeyManagerScreen> createState() => _KeyManagerScreenState();
}

class _KeyManagerScreenState extends State<KeyManagerScreen> {
  List<ApiKey> _keys = [];
  bool _loading = true;
  String? _error;

  @override
  void initState() {
    super.initState();
    _refresh();
  }

  Future<void> _refresh() async {
    setState(() {
      _loading = true;
      _error = null;
    });
    try {
      final keys = await widget.api.listApiKeys();
      setState(() {
        _keys = keys;
        _loading = false;
      });
    } catch (e) {
      setState(() {
        _error = 'Keys load nahi ho saki: $e';
        _loading = false;
      });
    }
  }

  Future<void> _createKey() async {
    final labelController = TextEditingController();
    final label = await showDialog<String>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('New Key Label'),
        content: TextField(
          controller: labelController,
          decoration: const InputDecoration(hintText: 'e.g. Backup Uploader'),
        ),
        actions: [
          TextButton(
              onPressed: () => Navigator.pop(ctx), child: const Text('Cancel')),
          FilledButton(
              onPressed: () => Navigator.pop(ctx, labelController.text.trim()),
              child: const Text('Next')),
        ],
      ),
    );
    if (label == null || label.isEmpty || !mounted) return;

    // Follow-up fix (P1-02) — registered custom capabilities fetch karte
    // hain taaki wizard unhe "Custom Capabilities" section mein dikha
    // sake. Fetch fail ho jaaye (network issue, waghera) to bhi wizard
    // khulti hai — sirf woh section khaali rahega, poora flow block nahi
    // hota is ek optional cheez ki wajah se.
    List<CapabilityManifest> customCapabilities = const [];
    try {
      final all = await widget.api.getCapabilities();
      customCapabilities = all.where((c) => c.isCustom).toList();
    } catch (_) {
      // Silently ignore — dekhein upar wala comment.
    }

    // Section 3.2 — same wizard as first-time setup.
    if (!mounted) return;
    await Navigator.push(
      context,
      MaterialPageRoute(
        builder: (_) => PermissionWizard(
          title: 'Scope for "$label"',
          availableCustomCapabilities: customCapabilities,
          onConfirm: (scope) async {
            Navigator.pop(context); // close wizard
            try {
              final newKey =
                  await widget.api.createApiKey(label: label, scope: scope);
              if (!mounted) return;
              await showDialog(
                context: context,
                builder: (ctx) => _KeyCreatedDialog(
                  keyId: newKey.keyId,
                  secret: newKey.secret ?? '',
                  controlApiUrl: widget.api.baseUrl.toString(),
                ),
              );
              _refresh();
            } catch (e) {
              if (!mounted) return;
              ScaffoldMessenger.of(context)
                  .showSnackBar(SnackBar(content: Text('Failed: $e')));
            }
          },
        ),
      ),
    );
  }

  Future<void> _setEnabled(ApiKey key, bool enabled) async {
    try {
      await widget.api.setApiKeyEnabled(key.keyId, enabled);
      _refresh();
    } catch (e) {
      if (!mounted) return;
      ScaffoldMessenger.of(context)
          .showSnackBar(SnackBar(content: Text('Failed: $e')));
    }
  }

  Future<void> _revoke(ApiKey key) async {
    final confirm = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('Revoke Key?'),
        content: Text('"${key.label}" turant band ho jayegi.'),
        actions: [
          TextButton(
              onPressed: () => Navigator.pop(ctx, false),
              child: const Text('Cancel')),
          FilledButton(
              style: FilledButton.styleFrom(backgroundColor: Colors.red),
              onPressed: () => Navigator.pop(ctx, true),
              child: const Text('Revoke')),
        ],
      ),
    );
    if (confirm != true) return;
    try {
      await widget.api.revokeApiKey(key.keyId);
      _refresh();
    } catch (e) {
      if (!mounted) return;
      ScaffoldMessenger.of(context)
          .showSnackBar(SnackBar(content: Text('Revoke failed: $e')));
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('API Keys')),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: _createKey,
        icon: const Icon(Icons.add),
        label: const Text('Create New API Key'),
      ),
      body: _loading
          ? const Center(child: CircularProgressIndicator())
          : _error != null
              ? Center(child: Text(_error!))
              : RefreshIndicator(
                  onRefresh: _refresh,
                  child: ListView.builder(
                    itemCount: _keys.length,
                    itemBuilder: (ctx, i) {
                      final k = _keys[i];
                      return ListTile(
                        leading: Icon(k.enabled
                            ? Icons.vpn_key
                            : Icons.vpn_key_off_outlined),
                        title: Text(k.label),
                        subtitle: Text(_scopeSummary(k.scope)),
                        trailing: Row(
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            Switch(
                              value: k.enabled,
                              onChanged: (v) => _setEnabled(k, v),
                            ),
                            IconButton(
                              icon: const Icon(Icons.delete_outline),
                              onPressed: () => _revoke(k),
                            ),
                          ],
                        ),
                      );
                    },
                  ),
                ),
    );
  }

  String _scopeSummary(ApiKeyScope s) {
    final on = <String>[
      if (s.screenView) 'Screen',
      if (s.touchInput) 'Input',
      if (s.keyboardText) 'Keyboard',
      if (s.files) 'Files',
      if (s.apps) 'Apps',
      if (s.browser) 'Browser',
      if (s.clipboard) 'Clipboard',
      if (s.dataTransfer) 'Data',
      if (s.contacts) 'Contacts',
      if (s.location) 'Location',
      if (s.background) 'Background',
      if (s.messagingReply) 'Messaging Reply',
    ];
    return on.isEmpty ? 'No permissions granted' : on.join(' · ');
  }
}

/// Naya key create hone ke turant baad dikhta hai — secret sirf **ek hi
/// baar** yahan visible hota hai (server dobara kabhi return nahi karta).
///
/// QR code isi secret ko ek compact JSON mein encode karta hai
/// (`{api_url, key_id, secret}`) — taaki koi doosra tool/device (jaise
/// ek AI agent setup screen) is key ko **scan karke** seedha le sake,
/// lambi secret string haath se type na karni pade. Yeh QR sirf isi
/// dialog mein dikhta hai, kahin save/log nahi hota.
class _KeyCreatedDialog extends StatelessWidget {
  final String keyId;
  final String secret;
  final String controlApiUrl;

  const _KeyCreatedDialog({
    required this.keyId,
    required this.secret,
    required this.controlApiUrl,
  });

  @override
  Widget build(BuildContext context) {
    final qrData = jsonEncode({
      'api_url': controlApiUrl,
      'key_id': keyId,
      'secret': secret,
    });

    return AlertDialog(
      title: const Text('Key Created'),
      content: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          const Text(
            'Yeh secret sirf ABHI, ek hi baar dikhega — dobara kabhi nahi '
            'milega. Ise scan kar lein ya save kar lein.',
            textAlign: TextAlign.center,
          ),
          const SizedBox(height: 16),
          // QR code — koi doosra device/tool isko scan karke seedha yeh
          // key use karna shuru kar sakta hai, type kiye bina.
          Container(
            padding: const EdgeInsets.all(12),
            decoration: BoxDecoration(
              color: Colors.white,
              borderRadius: BorderRadius.circular(8),
            ),
            child: QrImageView(
              data: qrData,
              version: QrVersions.auto,
              size: 220,
              backgroundColor: Colors.white,
            ),
          ),
          const SizedBox(height: 16),
          const Align(
            alignment: Alignment.centerLeft,
            child: Text('Ya secret text copy karein:',
                style: TextStyle(fontWeight: FontWeight.w600)),
          ),
          const SizedBox(height: 4),
          SelectableText(secret, style: const TextStyle(fontFamily: 'monospace')),
        ],
      ),
      actions: [
        FilledButton(
          onPressed: () => Navigator.pop(context),
          child: const Text('Done'),
        ),
      ],
    );
  }
}
