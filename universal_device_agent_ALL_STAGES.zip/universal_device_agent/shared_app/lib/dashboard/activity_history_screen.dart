import 'package:flutter/material.dart';
import '../protocol/activity_event.dart';
import '../protocol/api_client.dart';

class ActivityHistoryScreen extends StatefulWidget {
  final DeviceAgentApiClient api;
  final String deviceId;
  const ActivityHistoryScreen(
      {super.key, required this.api, required this.deviceId});

  @override
  State<ActivityHistoryScreen> createState() => _ActivityHistoryScreenState();
}

class _ActivityHistoryScreenState extends State<ActivityHistoryScreen> {
  List<ActivityEvent> _events = [];
  bool _loading = true;
  String? _error;

  @override
  void initState() {
    super.initState();
    _refresh();
  }

  Future<void> _refresh() async {
    setState(() {
      _loading = true;
      _error = null;
    });
    try {
      final events = await widget.api.getActivityHistory(widget.deviceId);
      setState(() {
        _events = events;
        _loading = false;
      });
    } catch (e) {
      setState(() {
        _error = 'History load nahi ho saki: $e';
        _loading = false;
      });
    }
  }

  IconData _iconFor(String eventType) => switch (eventType) {
        'message_reply' => Icons.reply,
        'location_updated' => Icons.location_on_outlined,
        'network_changed' => Icons.wifi,
        'device_online' => Icons.cloud_done_outlined,
        'device_offline' => Icons.cloud_off_outlined,
        'switch_event' => Icons.swap_horiz,
        _ => Icons.history,
      };

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Activity History')),
      body: _loading
          ? const Center(child: CircularProgressIndicator())
          : _error != null
              ? Center(child: Text(_error!))
              : RefreshIndicator(
                  onRefresh: _refresh,
                  child: _events.isEmpty
                      ? ListView(children: const [
                          Padding(
                            padding: EdgeInsets.all(32),
                            child: Center(child: Text('Koi activity nahi.')),
                          )
                        ])
                      : ListView.builder(
                          itemCount: _events.length,
                          itemBuilder: (ctx, i) {
                            final e = _events[i];
                            return ListTile(
                              leading: Icon(_iconFor(e.eventType),
                                  color: e.succeeded ? Colors.green : Colors.red),
                              title: Text(e.eventType),
                              subtitle: Text(
                                  '${e.actor}${e.source != null ? ' · ${e.source}' : ''}'
                                  ' · ${e.timestamp.toLocal()}'),
                              trailing: Text(e.status),
                            );
                          },
                        ),
                ),
    );
  }
}
