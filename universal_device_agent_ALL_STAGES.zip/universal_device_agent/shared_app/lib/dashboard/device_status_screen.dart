import 'package:flutter/material.dart';
import '../protocol/api_client.dart';
import '../protocol/device_status.dart';

/// Section 10.1 (Power/Lock/Screen/Connection/Background) + Section 11.4
/// (Location + Network) — ek hi combined card, jaisa doc mein diagram diya
/// gaya hai.
class DeviceStatusScreen extends StatefulWidget {
  final DeviceAgentApiClient api;
  final String deviceId;
  const DeviceStatusScreen(
      {super.key, required this.api, required this.deviceId});

  @override
  State<DeviceStatusScreen> createState() => _DeviceStatusScreenState();
}

class _DeviceStatusScreenState extends State<DeviceStatusScreen> {
  DeviceStatus? _status;
  bool _loading = true;
  String? _error;

  @override
  void initState() {
    super.initState();
    _refresh();
  }

  Future<void> _refresh() async {
    setState(() {
      _loading = true;
      _error = null;
    });
    try {
      final status = await widget.api.getDeviceStatus(widget.deviceId);
      if (!mounted) return;
      setState(() {
        _status = status;
        _loading = false;
      });
    } catch (e) {
      if (!mounted) return;
      setState(() {
        // Section 11.4 — UI ko clearly batana chahiye jab value OS
        // permission/privacy/offline ki wajah se unavailable ho.
        _error = 'Status unavailable (offline, permission, ya platform '
            'limitation ho sakti hai): $e';
        _loading = false;
      });
    }
  }

  Future<void> _locateDevice() async {
    try {
      // Section 4 ka generic pattern reuse: ek "locate" command bhejna
      // location capability ke through.
      await widget.api.sendCommand(
        capability: 'location',
        action: 'location.refresh',
      );
      _refresh();
    } catch (e) {
      if (!mounted) return;
      ScaffoldMessenger.of(context)
          .showSnackBar(SnackBar(content: Text('Locate failed: $e')));
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Device Status')),
      body: _loading
          ? const Center(child: CircularProgressIndicator())
          : _error != null
              ? Center(
                  child: Padding(
                    padding: const EdgeInsets.all(24),
                    child: Text(_error!, textAlign: TextAlign.center),
                  ),
                )
              : RefreshIndicator(
                  onRefresh: _refresh,
                  child: ListView(
                    padding: const EdgeInsets.all(16),
                    children: [
                      Card(
                        child: Padding(
                          padding: const EdgeInsets.all(16),
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              _row('Status', _status!.state.label),
                              _row('Background',
                                  _status!.backgroundActive ? 'Active' : 'Idle'),
                              _row(
                                  'Battery',
                                  _status!.batteryPercent != null
                                      ? '${_status!.batteryPercent}%'
                                      : '--'),
                              const Divider(),
                              _row(
                                  'Location',
                                  _status!.lastKnownLocation != null
                                      ? 'Last known: '
                                          '${_status!.lastKnownLocation!.latitude.toStringAsFixed(4)}, '
                                          '${_status!.lastKnownLocation!.longitude.toStringAsFixed(4)}'
                                      : 'Unavailable'),
                              _row(
                                  'Updated',
                                  _status!.lastKnownLocation != null
                                      ? _status!.lastKnownLocation!.timestamp
                                          .toLocal()
                                          .toString()
                                      : '--'),
                              const Divider(),
                              _row(
                                  'Network',
                                  _status!.network?.connected == true
                                      ? 'Connected'
                                      : 'Disconnected'),
                              // SSID masked in UI, jaisa Section 11.4 mockup mein hai.
                              _row('SSID',
                                  _status!.network?.ssid != null ? '••••••••' : '--'),
                              _row('Type', _status!.network?.connectionType ?? '--'),
                            ],
                          ),
                        ),
                      ),
                      const SizedBox(height: 16),
                      Row(
                        children: [
                          Expanded(
                            child: OutlinedButton.icon(
                              onPressed: _refresh,
                              icon: const Icon(Icons.refresh),
                              label: const Text('Refresh Status'),
                            ),
                          ),
                          const SizedBox(width: 12),
                          Expanded(
                            child: FilledButton.icon(
                              onPressed: _locateDevice,
                              icon: const Icon(Icons.location_searching),
                              label: const Text('Locate Device'),
                            ),
                          ),
                        ],
                      ),
                    ],
                  ),
                ),
    );
  }

  Widget _row(String label, String value) => Padding(
        padding: const EdgeInsets.symmetric(vertical: 4),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Text(label, style: const TextStyle(color: Colors.grey)),
            Text(value, style: const TextStyle(fontWeight: FontWeight.w600)),
          ],
        ),
      );
}
