import 'package:flutter/material.dart';
import '../protocol/event_envelope.dart';

/// Section 2.2 — "Step timeline: har action ek list mein add hota jaye
/// (action, timestamp, result: success/fail)".
class StepTimeline extends StatelessWidget {
  final List<TaskProgressEvent> steps;
  const StepTimeline({super.key, required this.steps});

  @override
  Widget build(BuildContext context) {
    if (steps.isEmpty) {
      return const Padding(
        padding: EdgeInsets.all(24),
        child: Center(child: Text('Task shuru hone ka intezaar...')),
      );
    }
    return ListView.builder(
      reverse: true, // latest step upar
      itemCount: steps.length,
      itemBuilder: (ctx, i) {
        final step = steps[steps.length - 1 - i];
        return ListTile(
          leading: Icon(
            step.succeeded ? Icons.check_circle : Icons.error,
            color: step.succeeded ? Colors.green : Colors.red,
          ),
          title: Text('Step ${step.step}: ${step.description}'),
          subtitle: Text('${step.action} · ${step.timestamp.toLocal()}'
              '${step.durationMs != null ? ' · ${step.durationMs}ms' : ''}'),
          trailing: step.screenshotUrl != null
              ? const Icon(Icons.image_outlined, size: 20)
              : null,
        );
      },
    );
  }
}
