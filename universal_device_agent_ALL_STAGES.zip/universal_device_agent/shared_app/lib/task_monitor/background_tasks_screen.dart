import 'package:flutter/material.dart';
import '../protocol/api_client.dart';
import '../protocol/device_status.dart';

/// Section 9 — Locked-Device Background Agent & Messaging.
/// Screen automation ke bina bhi background events/replies ka status
/// dikhata hai, jab device LOCKED ya SCREEN_OFF state mein ho.
class BackgroundTasksScreen extends StatefulWidget {
  final DeviceAgentApiClient api;
  final String deviceId;
  const BackgroundTasksScreen(
      {super.key, required this.api, required this.deviceId});

  @override
  State<BackgroundTasksScreen> createState() => _BackgroundTasksScreenState();
}

class _BackgroundTasksScreenState extends State<BackgroundTasksScreen> {
  DeviceStatus? _status;
  bool _loading = true;

  @override
  void initState() {
    super.initState();
    _refresh();
  }

  Future<void> _refresh() async {
    setState(() => _loading = true);
    try {
      final status = await widget.api.getDeviceStatus(widget.deviceId);
      if (!mounted) return;
      setState(() {
        _status = status;
        _loading = false;
      });
    } catch (_) {
      if (!mounted) return;
      setState(() => _loading = false);
    }
  }

  // Item 36: pehle try/catch nahi tha — server/network error par
  // unhandled exception aur koi feedback nahi.
  Future<void> _sendKeepalive() async {
    // Section 9.3 — background.keepalive action.
    try {
      await widget.api.sendCommand(
        capability: 'background',
        action: 'background.keepalive',
      );
      await _refresh();
    } catch (e) {
      if (!mounted) return;
      ScaffoldMessenger.of(context)
          .showSnackBar(SnackBar(content: Text('Keepalive failed: $e')));
    }
  }

  @override
  Widget build(BuildContext context) {
    final state = _status?.state;
    // Section 9.4 — screen control se separate: yahan sirf background-capable
    // actions dikhaye jaate hain, screen automation nahi.
    final canRunBackground = state?.allowsBackgroundActions ?? false;

    return Scaffold(
      appBar: AppBar(title: const Text('Background Tasks')),
      body: _loading
          ? const Center(child: CircularProgressIndicator())
          : RefreshIndicator(
              onRefresh: _refresh,
              child: ListView(
                padding: const EdgeInsets.all(16),
                children: [
                  Card(
                    child: ListTile(
                      leading: Icon(
                        canRunBackground
                            ? Icons.bolt_outlined
                            : Icons.bolt_outlined,
                        color: canRunBackground ? Colors.green : Colors.grey,
                      ),
                      title: Text('Device state: ${state?.label ?? 'Unknown'}'),
                      subtitle: Text(canRunBackground
                          ? 'Background-capable actions available '
                              '(notifications, messaging, keepalive)'
                          : 'Background automation not available in this state'),
                    ),
                  ),
                  const SizedBox(height: 8),
                  // Section 9.3 — notifications/messaging/background actions.
                  // Actual list Control API se GET /capabilities ke zariye
                  // discover hoti hai (Section 9.7); yahan sirf fixed
                  // top-level actions ka shortcut diya gaya hai.
                  ListTile(
                    leading: const Icon(Icons.notifications_none),
                    title: const Text('Notifications & Messaging'),
                    subtitle: const Text(
                        'notifications.read_event · messaging.get_event · '
                        'messaging.prepare_reply · messaging.send_reply'),
                    enabled: canRunBackground,
                  ),
                  ListTile(
                    leading: const Icon(Icons.favorite_border),
                    title: const Text('Keepalive'),
                    subtitle: const Text('Background session ko zinda rakhein'),
                    trailing: FilledButton(
                      onPressed: canRunBackground ? _sendKeepalive : null,
                      child: const Text('Send'),
                    ),
                  ),
                ],
              ),
            ),
    );
  }
}
