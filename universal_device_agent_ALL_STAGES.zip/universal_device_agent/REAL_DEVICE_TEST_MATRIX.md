# Real-device test matrix (item 94) — pass/fail yahan likhein

Pehle: `dart test` + `flutter test` green hon. Phir har row ko actual device par chalao.

| # | Test | Android | Windows | Linux X11 | Linux Wayland |
|---|---|---|---|---|---|
| 1 | Pair → restart app → **naya device nahi bana** (item 24) | | | | |
| 2 | Dashboard "Locate"/"Keepalive" (owner endpoints, 401 nahi) | | | | |
| 3 | Permission Center: screen capture / input / files / contacts / location | | n/a | n/a | n/a |
| 4 | `screen.capture` — image kholne par sahi dikhe (static screen par bhi) | | | | ⛔ unsupported |
| 5 | `screen.watch_live` ~6–8 fps, stop par ruk jaye, complete/fail par ruk jaye | | | | |
| 6 | `input.tap/swipe/type_text` (+ append); elevated window par saaf error | | | | |
| 7 | `files.list/read/write` sandbox + picked folder; 10 MiB upload end-to-end | | | | |
| 8 | `browser.navigate` http ok, `file://` reject; `browser.read/click` real Chrome par | | | | |
| 9 | `app_launcher.launch` listed app ok; random command reject | | | | |
| 10 | `clipboard.read/write` (Android: background mein saaf error) | | | | |
| 11 | Lock/unlock ka status dashboard par badle (GNOME, Windows lock) | | | | |
| 12 | Battery/network/location Device Status mein dikhe | | | | |
| 13 | Wi-Fi band/on → agent auto-reconnect (backoff), dashboard "online/offline" | | | | |
| 14 | Server restart → sessions/tasks wapas, devices OFFLINE → reconnect par ONLINE | | | | |
| 15 | Android: notification access ON → `notifications.read_event` | | n/a | n/a | n/a |
| 16 | Android: back press → app background, agent online rehta hai; battery exemption | | n/a | n/a | n/a |
| 17 | Google Drive/Dropbox OAuth + list + **download** (Docs export) | | | | |
| 18 | Railway deploy: `/healthz`, Volume `/data` persistence, `CONFIG WARNING` logs | | | | |
| 19 | Unpair (dashboard) → server se device/keys gayab, app pairing par wapas | | | | |
| 20 | Release APK: keystore ke saath sign (`-PrequireReleaseKeystore=true`) | | n/a | n/a | n/a |
