# Audit documents ke mutabik: kya hua, kya baki hai

Legend: ✅ code mein ho gaya (par **unverified** — kuch bhi compile/run nahi hua) · 🧪 aapko run/test karna hai · ⛔ nahi kiya (kyun, likha hai)

## A. Audit ke "Exact priority order" (Section 13) ka status
| # | Audit ka step | Status |
|---|---|---|
| 1 | WebSocket authenticate + authorize | ✅ Server par pehle se tha; **client header nahi bhejta tha → fix (item 26)**; cross-device session/event/frame injection band (6–7) |
| 2 | Task checkpoint/resume/complete/fail | ✅ Pehle se mostly tha; ab server-side complete/fail device ko `task_state` se bhi pahunchta hai (56), stale tasks prune (59) |
| 3 | Dart/Flutter tests chalana | 🧪 **Aap**: `dart test` / `flutter test`. Mene 40 test files likhi hain, ek bhi chali nahi |
| 4 | Android debug APK + real device tests | 🧪 **Aap** (`scripts/bootstrap_platforms.sh` pehle) |
| 5 | Android lock-state + background agent | ✅ Lock-state intent-based (71); foreground service + back-press→background + battery exemption (85). ⛔ Poora "Activity ke bina chalne wala" background isolate nahi — device par design/test chahiye |
| 6 | Windows build + capability matrix | 🧪 **Aap** (Windows screen capture/clipboard/input mein asli bugs mile aur fix kiye — item 83) |
| 7 | Linux X11 + Wayland test | 🧪 **Aap** |
| 8 | Notification/messaging adapters | ✅ Android notifications (84). ⛔ WhatsApp/SMS jaise messaging adapters jaan-bujh kar `CAPABILITY_UNAVAILABLE` (audit khud kehta hai unsupported target ko aise hi rakho) |
| 9 | Signing, branding, deployment | ✅ Release keystore ke bina build fail karne ka opt-in (`-PrequireReleaseKeystore=true`); Railway/env warnings. ⛔ **Branding/icons: design assets chahiye** |
| 10 | Matrix dobara + "Complete" tab likhna jab evidence ho | 🧪 `REAL_DEVICE_TEST_MATRIX.md` |

## B. Roadmap items (Section 3)
| ID | Audit verdict | Ab |
|---|---|---|
| P0-01 Task lifecycle | 🟡 | ✅ + custom-capability tasks ab pause/stop ho sakte hain (45) |
| P0-02 Scope enforcement | 🟡 | ✅ + owner endpoints (25), ownership (6) |
| P0-03 HTTPS/WSS | 🟡 | ✅ Railway auto-detect (4); direct TLS wahi |
| P0-04 Schema validation | 🟡 | ✅ + body-size, URL scheme, file-type hardening (13, 14, 16, 39) |
| P0-05 Rate limiting | 🟡 | ✅ proxy-aware IP, pairing bucket (17). ⛔ Multi-instance (Redis) nahi (90) |
| P0-06 Secrets/log redaction | 🟡 | ✅ constant-time compare, 128-bit ids, key expiry (19, 21, 22) |
| P0-07 Connector OAuth | 🟡 | ✅ refresh race/invalid_grant (47), **download (Drive+Dropbox)**, API key (dataTransfer scope) access (86). ⛔ Upload nahi (write scopes = zyada privilege; deliberate) |
| P1-01 Capability registry | 🟡 | ✅ per-device ownership + caps (15) |
| P1-02 AI tool registry | 🟡 | ✅ control.* tools ab dikhte hain (46). ⛔ AI engine is repo ka hissa nahi (boundary) |
| P1-03 Live monitoring | 🟠 | ✅ auth+retry (26–27), FPS cap/throttle (57, 63), snapshot (34), Windows screen capture ke real bugs (83). 🧪 end-to-end test |
| P1-04 Progress metadata | 🟡 | unchanged |
| P1-05 Device state | 🟠 | ✅ reconnect par full status (33), stale sweeper/ping (43), Android + Linux(GNOME) lock-state (71, 83) |
| P1-06 Notifications+messaging | 🔴 | ✅ notifications (Android); ⛔ messaging adapters |
| P1-07 Location/network | 🟡 | ✅ ab server tak pahunchta hai (32), battery (32), Android fallbacks (69) |
| P1-08 File/data hardening | 🟡 | ✅ Android picked-tree check (67), desktop non-throwing/size caps/persisted roots (81–82) |
| P1-09 Audit history | 🟡 | unchanged |
| DEP-01 Deployment | 🟡 | ✅ + persistence race/corruption safe (40–42) |

## C. Jo abhi bhi baki hai (honest list)
**Aapko karna hai (main nahi kar sakta):**
1. `dart pub get && dart analyze && dart test`, `flutter pub get && flutter analyze && flutter test` — **errors mujhe bhejo, main batch mein fix karunga.** (Compile errors milna *expected* hai: ~50 files blind likhi/badli gayi.)
2. `scripts/bootstrap_platforms.sh` (Flutter platform scaffolding), `pubspec.lock` commit.
3. Real device matrix (`REAL_DEVICE_TEST_MATRIX.md`).
4. Railway env vars (`HOW_TO_CONNECT.md`), release keystore.

**Design/product decision ya assets chahiye (⛔):**
- Item 10: server-issued one-time pairing-code registry (abhi `PAIRING_SECRET`).
- Item 85: Android background isolate jo Activity ke bina chale + Windows tray/service + Linux systemd (abhi: Android foreground service + desktop autostart).
- Item 86: connector upload; Item 84: messaging adapters.
- Item 88: real icons/branding/splash/installers.
- Item 89: UI/UX redesign (audit Section 11).
- Item 90: multi-instance scaling (Redis).
- Item 14: native layers par alag file-type check (abhi server + Dart dispatcher).
- Item 22: hash-indexed key lookup (O(n) rehta hai).
- Item 81: desktop file IO abhi UI thread par (Flutter Windows/Linux result ko thread se call karna safe nahi; size cap laga hai).

**Known limitations jo dhyan mein rakhein:**
- Chrome pehle se bina debug-port ke chal raha ho to Chrome naya `--remote-debugging-port` accept nahi karta — browser band karke dobara try karna padega (78).
- WebSocket auth-failure detection `WebSocketException` ke message mein 401/403 dhundhta hai; Dart version ke hisaab se message alag ho sakta hai (53) — REST 401 handler backup hai.
- Windows `Graphics.Capture` ka PostMessage/subclass approach compile/run nahi hua (83).
