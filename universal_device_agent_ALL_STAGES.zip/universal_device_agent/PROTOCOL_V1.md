# Protocol v1 — FROZEN

Yeh spec **frozen** hai (audit ka P0 item #1 — Developer Implementation
Order, step 1: "Freeze protocol_v1 and define canonical command/event/
error envelopes"). Frozen ka matlab: in teeno envelope shapes ke
**required fields kabhi remove/rename nahi honge** — naye fields sirf
**add** ho sakte hain (aur unhe optional rakhna hoga, taaki purana client
naye server ke saath aur naya client purane server ke saath bhi chal
sake — backward/forward compatible).

Dono taraf (client aur server) isi document ko source-of-truth maante
hain:
- Client: `shared_app/lib/protocol/command_envelope.dart`,
  `event_envelope.dart`
- Server: `control_api/lib/models/errors.dart`, `routes/commands.dart`

Har envelope mein `protocol_version` field hai — agar kabhi breaking
change karni pade (field remove/rename), to version `"2.0"` banega, aur
server dono versions ko kuch waqt tak support karega (migration
window), is se pehle purana version deprecate nahi hoga.

---

## 1. Command Envelope

Client → Server → Device. Field order yahan documentation ke liye hai,
JSON mein order matter nahi karta.

```json
{
  "protocol_version": "1.0",
  "request_id": "b3f1c2a4-...",
  "api_key_id": "key_8f2a91c0",
  "capability": "screen",
  "action": "screen.capture",
  "params": { },
  "payload": null,
  "timeout_ms": 8000
}
```

| Field | Type | Required | Notes |
|---|---|---|---|
| `protocol_version` | string | **haan** | `"1.0"` — major.minor. Server sirf supported major version accept karta hai. |
| `request_id` | string (UUID) | **haan** | Response/event correlation ke liye. |
| `api_key_id` | string | **haan** | Scoped key ka ID — is se `Authorization: Bearer <secret>` verify hota hai. |
| `capability` | string | **haan** | e.g. `"screen"`, `"input"`, `"files"`. |
| `action` | string | **haan** | `"<capability>.<verb>"` convention. |
| `params` | object | nahi (default `{}`) | Action-specific. |
| `payload` | string (base64) ya null | nahi | Sirf Data Channel actions ke liye. |
| `timeout_ms` | number | nahi | Default server-side. |

**Coordinate contract (`input.tap`/`input.swipe`)** — jaan-bujh kar yahan
explicit likha hai, kyunki koi bhi caller (AI orchestrator ho ya koi
aur client) is envelope se seedha reverse-engineer nahi kar sakta:
`x`/`y` (aur `x1,y1,x2,y2`) hamesha **absolute pixel coordinates** hain
(origin `0,0` top-left), us device ke real screen resolution ke against
— bilkul wahi resolution jo sabse recent `screen.capture`/
`screen.watch_live` frame ki image dimensions mein milta hai. Yeh
normalized (0.0–1.0) fractions **nahi** hain, aur teeno platforms
(Android/Windows/Linux) is contract ko consistently follow karte hain
(native implementations verify kiye gaye).

## 2. Event Envelope

Device → Server → Client (WebSocket `/sessions/{id}`).

```json
{
  "protocol_version": "1.0",
  "type": "task_progress",
  "session_id": "sess_...",
  "timestamp": "2026-09-16T10:30:00Z",
  "step": 4,
  "action": "input.tap",
  "description": "Clicking 'Submit' button",
  "result": "success",
  "screenshot_url": null
}
```

`type` ke known values: `task_progress`, `switch_event`, `task_state`
(naya — P0-01 task lifecycle ke liye). Unknown `type` client-side
`UnknownEvent` mein fall-through hota hai (forward-compatible — naya
event type add karna kabhi bhi purane client ko crash nahi karega).

**`task_state` (naya, P0-01):** jab bhi server ka `TaskRecord`
state-machine ek transition apply karta hai (`control.pause` /
`control.resume` / `control.stop` se), yeh event us session ke saare
listeners ko broadcast hota hai:

```json
{
  "protocol_version": "1.0",
  "type": "task_state",
  "session_id": "sess_...",
  "task_id": "sess_...",
  "state": "PAUSED",
  "timestamp": "2026-09-18T10:30:00Z"
}
```

`task_id` abhi `session_id` ke barabar hai (P0-01 ne yeh conscious
decision liya — envelope ka `params.session_id` hi task correlation id
ke tor par use ho raha hai, taaki koi naya required field add na karna
pade; dono fields is liye duplicate hain — future minor version mein
`session_id` chhod kar sirf `task_id` rakha ja sakta hai). `state` ka
enum: `RUNNING`, `PAUSED`, `STOPPED`, `COMPLETED`, `FAILED`.

| Field | Type | Required |
|---|---|---|
| `protocol_version` | string | **haan** |
| `type` | string | **haan** |
| `session_id` | string | **haan** (device-side se — server isko WS-multiplexing ke through fill karta hai) |
| `timestamp` | string (ISO 8601) | **haan** |
| ...type-specific fields | — | type ke hisaab se |

## 3. Error Envelope — canonical, HAR error response isi shape mein

Pehle server ka har route apna alag ad-hoc `{"error": "..."}` string
bhejta tha — ab **sab jagah** yeh exact shape hai:

```json
{
  "error": {
    "code": "SCOPE_DENIED",
    "message": "Yeh key \"input\" capability ke liye authorized nahi hai",
    "request_id": "b3f1c2a4-..."
  }
}
```

| Field | Type | Required |
|---|---|---|
| `code` | string (enum, neeche list) | **haan** — machine-readable, client isi par switch kare, `message` par nahi (message badal sakta hai, `code` kabhi nahi) |
| `message` | string | **haan** — human-readable, sirf display ke liye |
| `request_id` | string ya null | jab applicable ho |

### Canonical error codes (frozen enum — naye codes add ho sakte hain, purane kabhi remove nahi honge)

| Code | HTTP status | Kab |
|---|---|---|
| `UNAUTHORIZED` | 401 | Bearer token invalid/missing |
| `SCOPE_DENIED` | 403 | Valid key, lekin is capability/action ki ijazat nahi |
| `FORBIDDEN` | 403 | Auth theek, lekin resource kisi aur ka hai (e.g. doosre device ki key) |
| `NOT_FOUND` | 404 | Device/key/session nahi mila |
| `INVALID_REQUEST` | 400 | Schema validation fail (P0-04) |
| `UNSUPPORTED_PROTOCOL_VERSION` | 400 | `protocol_version` major mismatch |
| `PAYLOAD_TOO_LARGE` | 413 | Size limit cross (P1-08) |
| `RATE_LIMITED` | 429 | P0-05 |
| `DEVICE_OFFLINE` | 503 | Command bheji, device connected nahi hai |
| `TIMEOUT` | 504 | Device ne timeout ke andar respond nahi kiya |
| `CAPABILITY_UNAVAILABLE` | 200 (result body mein, error nahi) | OS/platform is action ko support nahi karta — **yeh HTTP error nahi hai**, `messaging.*` jaisi cases ke liye (P1-06, "capability-unavailable result, not pretend success") |
| `INTERNAL` | 500 | Unexpected server error |

**`CAPABILITY_UNAVAILABLE` alag hai** — yeh HTTP-level error nahi, balke
command **result** ke andar aata hai (`{"result": {"error_code":
"CAPABILITY_UNAVAILABLE", ...}}`), kyunki request khud valid thi, bas
device/OS us action ko support nahi karta. Is distinction ko audit ka
MSG-01 test specifically maangta hai ("capability reports unavailable;
no false success").
